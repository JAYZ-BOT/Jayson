"""
Aviator Predictor Package Initialization
"""