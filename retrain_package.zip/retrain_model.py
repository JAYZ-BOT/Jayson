
import pandas as pd
import xgboost as xgb
import pickle

# Load dataset
df = pd.read_csv('data/aviator_payouts.csv')

# Example: Assume 'multiplier' is the target, the rest are features
X = df.drop('multiplier', axis=1)
y = df['multiplier']

# Train XGBoost model
model = xgb.XGBRegressor()
model.fit(X, y)

# Save the model
with open('aviator_xgb_model.pkl', 'wb') as f:
    pickle.dump(model, f)

print("Retraining complete. Model saved as aviator_xgb_model.pkl")
